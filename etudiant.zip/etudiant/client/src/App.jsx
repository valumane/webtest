import { useEffect, useState } from "react";

const GENRES = ["roman", "science-fiction", "policier", "essai"];

export default function App() {
    // TODO : états (liste, filtre, livre sélectionné, champs du formulaire, erreurs)

    // TODO : fonction qui recharge la liste (GET /api/livres, avec ?genre= si un filtre est choisi)

    useEffect(() => {
        // TODO : charger la liste au démarrage et quand le filtre change
    }, []);

    // TODO : fonctions pour ajouter, changer l'état de lecture, supprimer, afficher le détail

    return (
        <div style={{ padding: "2rem", maxWidth: 700 }}>
            <h1>Bibliothèque</h1>
            {
                // TODO : formulaire, filtre, liste, encadré de détail
            }
        </div>
    );
}
